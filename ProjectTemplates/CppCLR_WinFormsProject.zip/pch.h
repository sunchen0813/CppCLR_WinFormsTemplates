// pch.h: This is a precompiled header file.
// The files listed below are compiled only once to improve build performance for future builds.
// This also affects IntelliSense performance, including code completion and many code browsing features.
// However, the files listed here will ALL be recompiled if at least one of them is updated between builds.
// Do not add any files here that should be updated frequently, as this will reverse the performance benefit.

#ifndef PCH_H
#define PCH_H

// Add headers here to be precompiled.

#endif //PCH_H
